class FixAdditionalInformation < ActiveRecord::Migration
  def change 
    rename_column :local_populations, :addition_information, :additional_information
  end
end
