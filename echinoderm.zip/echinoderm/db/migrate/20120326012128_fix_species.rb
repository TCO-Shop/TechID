class FixSpecies < ActiveRecord::Migration
  def change
    rename_column :species, :name, :common_name
    add_column :species, :scientific_name, :string 
  end
end
