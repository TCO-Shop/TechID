class ChangeMetadatatoFile < ActiveRecord::Migration
  def change
    rename_column :local_populations, :metadata, :metadata_file_name
  end
end
