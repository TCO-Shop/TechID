class CreateLocalPopulations < ActiveRecord::Migration
  def change
    create_table :local_populations do |t|
      t.string :species_common_name
      t.integer :latitude
      t.integer :longitude
      t.string :photo_file_name
      t.string :addition_information, :limit => 1024
      t.string :metadata, :limit => 4096
      t.datetime :encountered_on

      t.timestamps
    end
  end
end
