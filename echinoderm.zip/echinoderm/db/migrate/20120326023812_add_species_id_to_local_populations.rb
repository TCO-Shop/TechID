class AddSpeciesIdToLocalPopulations < ActiveRecord::Migration
  def up
    add_column :local_populations, :species_id, :integer
    remove_column :local_populations, :species_common_namee
  end
  def down
    remove_column :local_populations, :species_id
    add_column :local_populations, :species_common_name, :string
  end
end
