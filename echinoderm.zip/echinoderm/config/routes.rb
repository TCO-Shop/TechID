Echinoderm::Application.routes.draw do
  root :to => 'species#index'
  
  resources :local_populations
  
  resources :species, :except => [:new, :create] do
   resources :local_populations
  end
end