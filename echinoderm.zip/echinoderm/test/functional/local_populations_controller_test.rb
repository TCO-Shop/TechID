require 'test_helper'

class LocalPopulationsControllerTest < ActionController::TestCase
  setup do
    @local_population = local_populations(:one)
  end

  test "should get index" do
    get :index
    assert_response :success
    assert_not_nil assigns(:local_populations)
  end

  test "should get new" do
    get :new
    assert_response :success
  end

  test "should create local_population" do
    assert_difference('LocalPopulation.count') do
      post :create, local_population: @local_population.attributes
    end

    assert_redirected_to local_population_path(assigns(:local_population))
  end

  test "should show local_population" do
    get :show, id: @local_population
    assert_response :success
  end

  test "should get edit" do
    get :edit, id: @local_population
    assert_response :success
  end

  test "should update local_population" do
    put :update, id: @local_population, local_population: @local_population.attributes
    assert_redirected_to local_population_path(assigns(:local_population))
  end

  test "should destroy local_population" do
    assert_difference('LocalPopulation.count', -1) do
      delete :destroy, id: @local_population
    end

    assert_redirected_to local_populations_path
  end
end
