require 'test_helper'

class LocalPopulationsHelperTest < ActionView::TestCase
end
