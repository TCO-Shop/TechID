require 'test_helper'

class SpeciesHelperTest < ActionView::TestCase
end
