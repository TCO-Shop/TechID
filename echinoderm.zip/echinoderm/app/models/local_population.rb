class LocalPopulation < ActiveRecord::Base
  has_attached_file :photo, :styles => {:thumb => '200x200'}
  has_attached_file :metadata
  
  belongs_to :species
  accepts_nested_attributes_for :species, :reject_if => 'common_name.blank?'
  
  after_initialize :init_associations
  
  validates_attachment_presence :photo
  
  def autosave_associated_records_for_species
    if new_species = Species.where(:common_name => species.common_name).first
      self.species = new_species
    else
      species.save!
      self.species = species
    end
  end
  
  def init_associations
    self.build_species if species.blank?
  end
  
end