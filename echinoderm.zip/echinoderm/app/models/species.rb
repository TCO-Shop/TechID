class Species < ActiveRecord::Base
  has_many :local_populations, :dependent => :destroy

  
  
end
