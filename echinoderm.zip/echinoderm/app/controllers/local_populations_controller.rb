class LocalPopulationsController < ApplicationController

  def index
    @local_populations = LocalPopulation.all
  end

def show
    respond_to do |format|
      format.html # index.html.erb
      format.json { render json: @local_populations }
    end
  end
  def show
    @local_population = LocalPopulation.find(params[:id])

    respond_to do |format|
      format.html # show.html.erb
      format.json { render json: @local_population }
    end
  end
  
  def new
    @local_population = LocalPopulation.new
  
  end

  # GET /local_populations/1/edit
  def edit
    @local_population = LocalPopulation.find(params[:id])
  end

  # POST /local_populations
  # POST /local_populations.json
  def create
    @local_population = LocalPopulation.new(params[:local_population])


    if @local_population.save
      redirect_to root_path, :notice => 'local population was successfully created'
    else
      render action: "new" 
    end
  end

  # PUT /local_populations/1
  # PUT /local_populations/1.json
  def update
    @local_population = LocalPopulation.find(params[:id])

    respond_to do |format|
      if @local_population.update_attributes(params[:local_population])
        format.html { redirect_to local_population_path(@local_population), notice: 'Local population was successfully updated.' }
        format.json { head :no_content }
      else
        format.html { render action: "edit" }
        format.json { render json: @local_population.errors, status: :unprocessable_entity }
      end
    end
  end

  # DELETE /local_populations/1
  # DELETE /local_populations/1.json
  def destroy
    @local_population = LocalPopulation.find(params[:id])
    @local_population.destroy

    respond_to do |format|
      format.html { redirect_to local_populations_url }
      format.json { head :no_content }
    end
  end
end
